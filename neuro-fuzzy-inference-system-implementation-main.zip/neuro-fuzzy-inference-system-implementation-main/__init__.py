from anfis.membership import membershipfunction
from anfis.membership import mfDerivs
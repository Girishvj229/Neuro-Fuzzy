# neuro-fuzzy-inference-system-implementation
Implementation Neuro Fuzzy Inference system using Python.
